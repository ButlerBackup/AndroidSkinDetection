package dev.mcidclan.skindetection4handh;

import android.app.Activity;
import android.os.Bundle;

import android.graphics.PixelFormat;
import android.content.pm.ActivityInfo;
import android.view.ViewGroup.LayoutParams;


public class Main extends Activity
{
    private Preview camerapreview;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        this.camerapreview = new Preview(this);

        this.getWindow().getAttributes().format = PixelFormat.RGBA_8888;
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        this.setContentView(camerapreview);
    }
}
